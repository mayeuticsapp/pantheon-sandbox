```javascript
document.addEventListener('DOMContentLoaded', () => {
    const productList = document.querySelector('.product-list');
    const cart = [];
    const cartTotal = document.querySelector('.cart-total');
    const cartItems = document.querySelector('.cart-items');

    // Fetch products from API or local data
    async function fetchProducts() {
        try {
            const response = await fetch('api/products'); // Replace with actual API endpoint
            const products = await response.json();
            displayProducts(products);
        } catch (error) {
            console.error('Error fetching products:', error);
        }
    }

    // Display products on the page
    function displayProducts(products) {
        productList.innerHTML = products.map(product => `
            <div class="product-item" data-id="${product.id}">
                <img src="${product.image}" alt="${product.name}">
                <h3>${product.name}</h3>
                <p>${product.price} €</p>
                <button class="add-to-cart">Aggiungi al carrello</button>
            </div>
        `).join('');

        document.querySelectorAll('.add-to-cart').forEach(button => {
            button.addEventListener('click', addToCart);
        });
    }

    // Add product to cart
    function addToCart(event) {
        const productItem = event.target.closest('.product-item');
        const productId = productItem.dataset.id;
        const productName = productItem.querySelector('h3').textContent;
        const productPrice = parseFloat(productItem.querySelector('p').textContent);

        const existingItem = cart.find(item => item.id === productId);
        if (existingItem) {
            existingItem.quantity++;
        } else {
            cart.push({ id: productId, name: productName, price: productPrice, quantity: 1 });
        }