```javascript
document.addEventListener('DOMContentLoaded', () => {
  // Responsive Navigation with Mobile Hamburger Menu
  const navToggle = document.querySelector('.nav-toggle');
  const navMenu = document.querySelector('.nav-menu');

  navToggle.addEventListener('click', () => {
    navMenu.classList.toggle('active');
  });

  // Product/Service Filtering and Search Functionality
  const searchInput = document.querySelector('#searchInput');
  const productCards = document.querySelectorAll('.product-card');

  searchInput.addEventListener('input', (event) => {
    const query = event.target.value.toLowerCase();
    productCards.forEach(card => {
      const title = card.querySelector('h2').textContent.toLowerCase();
      if (title.includes(query)) {
        card.style.display = '';
      } else {
        card.style.display = 'none';
      }
    });
  });

  // Contact Form with Validation and Submission Handling
  const contactForm = document.querySelector('#contactForm');
  const formFields = contactForm.querySelectorAll('input, textarea');
  const submitButton = contactForm.querySelector('button[type="submit"]');
  const feedbackMessage = contactForm.querySelector('.feedback-message');

  contactForm.addEventListener('input', (event) => {
    validateField(event.target);
  });